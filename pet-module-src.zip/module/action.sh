#!/system/bin/sh
# KernelSU / Magisk 管理器里的「操作」按钮：一键开关小人。
MODDIR=${0%/*}
PKG=com.dsh.pet

if pidof "$PKG" >/dev/null 2>&1; then
  am force-stop "$PKG"
  sleep 1
  if pidof "$PKG" >/dev/null 2>&1; then
    echo "已发送停止，但进程还在"
  else
    echo "小人已回家（已停止）"
  fi
else
  appops set "$PKG" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1
  am start -n "$PKG/.LauncherActivity" >/dev/null 2>&1
  sleep 2
  if pidof "$PKG" >/dev/null 2>&1; then
    echo "小人已上场"
  else
    echo "启动失败：确认 APK 已安装、悬浮窗权限已给"
  fi
fi
