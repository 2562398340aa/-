#!/system/bin/sh
# post-fs-data 阶段：阻塞式，必须在几秒内返回。
# 这里只重置日志，真正的活留给 service.sh。
MODDIR=${0%/*}
LOG=/data/local/tmp/screen_pet.log

[ -d /data/local/tmp ] && : > "$LOG"

exit 0
