#!/system/bin/sh
# late_start service 阶段：开机完成后安装并拉起小人。
MODDIR=${0%/*}
PKG=com.dsh.pet
LOG=/data/local/tmp/screen_pet.log
APK="$MODDIR/apk/pet.apk"

log() { echo "[$(date '+%m-%d %H:%M:%S')] $*" >> "$LOG"; }

log "service.sh 开始"

# 等系统真正开机完成，最多 3 分钟
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 180 ]; do
  sleep 1
  i=$((i + 1))
done
if [ "$(getprop sys.boot_completed)" != "1" ]; then
  log "等待开机超时，放弃本次拉起"
  exit 0
fi
log "开机完成，开始部署"

# 等一会儿再动手，避免和系统首个 App 启动抢资源
sleep 8

# 没装过就先装；已装过则只在版本变化时更新
if [ -f "$APK" ]; then
  if ! pm path "$PKG" >/dev/null 2>&1; then
    log "首次安装 APK"
    pm install -r -g "$APK" >>"$LOG" 2>&1
  else
    INSTALLED=$(dumpsys package "$PKG" 2>/dev/null | grep -m1 versionCode | tr -dc '0-9')
    log "已安装，versionCode=${INSTALLED:-未知}；换新 APK 后请重新刷模块或删除 $PKG 后重启"
  fi
else
  log "缺少 apk/pet.apk，跳过安装"
fi

# 悬浮窗权限：root 直接 appops 授权，不用手点
appops set "$PKG" SYSTEM_ALERT_WINDOW allow >>"$LOG" 2>&1
log "SYSTEM_ALERT_WINDOW -> $(appops get "$PKG" SYSTEM_ALERT_WINDOW 2>/dev/null)"

# 通知权限（Android 13+），没有也不影响小人，只是通知栏不显示
pm grant "$PKG" android.permission.POST_NOTIFICATIONS >>"$LOG" 2>&1

# 把小人加进省电白名单，避免 ColorOS 之类的 ROM 把服务杀掉
dumpsys deviceidle whitelist +"$PKG" >>"$LOG" 2>&1

# 拉起：走 LauncherActivity，由它转前台服务，避开后台启动 FGS 的限制
am start -n "$PKG/.LauncherActivity" >>"$LOG" 2>&1
log "am start 返回: $?"

sleep 3
if pidof "$PKG" >/dev/null 2>&1; then
  log "小人已上场 (pid $(pidof "$PKG"))"
else
  log "没起来，可能是 APK 未安装或悬浮窗被系统拒绝"
fi

log "service.sh 结束"
exit 0
