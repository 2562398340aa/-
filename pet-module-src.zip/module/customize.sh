#!/system/bin/sh
# 安装阶段执行：只做检查与权限修正，不做耗时的事。
SKIPUNZIP=0

ui_print "- 屏幕小人 screen_pet"
ui_print "- 设备: $(getprop ro.product.model) / Android $(getprop ro.build.version.release) / SDK $(getprop ro.build.version.sdk)"

# 只有 Magisk / KernelSU 的安装环境才有 BOOTMODE
if [ -z "$BOOTMODE" ]; then
  abort "! 请在 KernelSU 或 Magisk 管理器里刷入，不要在 recovery 里刷"
fi

if [ -f "$MODPATH/apk/pet.apk" ]; then
  ui_print "- 已内置 APK，开机后会自动安装并拉起"
else
  ui_print "! 没有找到 apk/pet.apk"
  ui_print "! 这样刷入不会有小人，模块只会装脚本"
fi

if [ "$(getprop ro.build.version.sdk)" -lt 26 ]; then
  abort "! 需要 Android 8.0 (SDK 26) 及以上"
fi

# 统一权限：脚本 755，其余 644
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/customize.sh"    0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh"      0 0 0755
set_perm "$MODPATH/action.sh"       0 0 0755
set_perm "$MODPATH/uninstall.sh"    0 0 0755

ui_print "- 安装完成，重启后生效"
ui_print "- KernelSU 管理器里可以点「操作」按钮开关小人"
