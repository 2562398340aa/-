#!/system/bin/sh
# 卸载模块时执行：停掉小人、收回权限、清日志。
PKG=com.dsh.pet
LOG=/data/local/tmp/screen_pet.log

am force-stop "$PKG" >/dev/null 2>&1
appops set "$PKG" SYSTEM_ALERT_WINDOW deny >/dev/null 2>&1
rm -f "$LOG"

# 注意：故意不卸载 APK。想彻底清干净，请手动执行：
#   pm uninstall com.dsh.pet
exit 0
