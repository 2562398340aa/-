#!/usr/bin/env node
/**
 * 生成两个诊断模块 zip，用来二分定位 KernelSU 安装失败的位置。
 *
 *   node tools/build-diag.js
 *
 * 产物：
 *   dist/diag-min.zip  只含 module.prop，能装说明 KSU 链路正常
 *   dist/diag-log.zip  带 customize.sh，会把环境变量写进 /data/local/tmp 并打印到控制台
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { buildZip } = require('./zipkit');

const ROOT = path.resolve(__dirname, '..');
const DIST = path.join(ROOT, 'dist');

const MIN_PROP = `id=screen_pet_min
name=屏幕小人最小测试
version=v0
versionCode=1
author=dsh
description=只有一个 module.prop 的最小模块。能装成功，说明 KSU 安装链路本身没问题。
`;

const DIAG_PROP = `id=screen_pet_diag
name=屏幕小人诊断
version=v0
versionCode=2
author=dsh
description=会把自己的安装环境写进 /data/local/tmp/screen_pet_diag.log，并打印到安装控制台。
`;

const DIAG_CUSTOMIZE = `#!/system/bin/sh
LOG=/data/local/tmp/screen_pet_diag.log

{
  echo "==== $(date) ===="
  echo "BOOTMODE=[$BOOTMODE]"
  echo "KSU=[$KSU]"
  echo "KSU_VER=[$KSU_VER] KSU_VER_CODE=[$KSU_VER_CODE]"
  echo "MAGISK_VER=[$MAGISK_VER]"
  echo "MODPATH=[$MODPATH]"
  echo "OUTFD=[$OUTFD]"
  echo "id=$(id 2>&1)"
  echo "sdk=$(getprop ro.build.version.sdk)"
  echo "PATH=$PATH"
} > "$LOG" 2>&1

ui_print "- 诊断已写入 $LOG"
ui_print "- BOOTMODE=$BOOTMODE"
ui_print "- MODPATH=$MODPATH"
ui_print "- 如果你能看到这行，customize.sh 确实被执行了"
`;

function build(entries, name) {
  const zip = buildZip(entries);
  fs.mkdirSync(DIST, { recursive: true });
  const target = path.join(DIST, name);
  fs.writeFileSync(target, zip);
  console.log(`${name}  ${(zip.length / 1024).toFixed(1)} KB  ${entries.length} 个文件`);
}

build(
  [{ name: 'module.prop', data: Buffer.from(MIN_PROP, 'utf8'), mtime: new Date(), mode: 0o644 }],
  'diag-min.zip',
);

build(
  [
    { name: 'META-INF/com/google/android/update-binary', data: fs.readFileSync(path.join(ROOT, 'module/META-INF/com/google/android/update-binary')), mtime: new Date(), mode: 0o755 },
    { name: 'META-INF/com/google/android/updater-script', data: Buffer.from('#MAGISK\n', 'utf8'), mtime: new Date(), mode: 0o644 },
    { name: 'module.prop', data: Buffer.from(DIAG_PROP, 'utf8'), mtime: new Date(), mode: 0o644 },
    { name: 'customize.sh', data: Buffer.from(DIAG_CUSTOMIZE, 'utf8'), mtime: new Date(), mode: 0o755 },
  ],
  'diag-log.zip',
);
