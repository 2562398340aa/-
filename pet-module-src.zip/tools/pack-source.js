#!/usr/bin/env node
/**
 * 把整个工程打成源码 zip，用于上传到 Colab / GitHub。
 *
 *   node tools/pack-source.js            → dist/pet-module-src.zip
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { collect, buildZip } = require('./zipkit');

const ROOT = path.resolve(__dirname, '..');
const DIST_DIR = path.join(ROOT, 'dist');

const SKIP = new Set([
  '.git',
  'dist',
  'android/.gradle',
  'android/build',
  'android/app/build',
  'android/local.properties',
]);

function main() {
  const entries = collect(ROOT, '', SKIP);

  entries.sort((a, b) => a.name.localeCompare(b.name));

  const zip = buildZip(entries);
  fs.mkdirSync(DIST_DIR, { recursive: true });
  const target = path.join(DIST_DIR, 'pet-module-src.zip');
  fs.writeFileSync(target, zip);

  console.log(`已生成: ${target}`);
  console.log(`  文件数: ${entries.length}`);
  console.log(`  体积:   ${(zip.length / 1024).toFixed(1)} KB`);
}

main();
