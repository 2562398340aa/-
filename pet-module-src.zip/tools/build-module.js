#!/usr/bin/env node
/**
 * 把 module/ 目录（外加一个 APK）打成可以直接刷入 KernelSU / Magisk 的 zip。
 *
 *   node tools/build-module.js <apk路径>
 *   node tools/build-module.js <apk路径> --out dist/xxx.zip
 *
 * 纯 Node 实现，不需要系统里有 zip 命令。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { collect, buildZip } = require('./zipkit');

const ROOT = path.resolve(__dirname, '..');
const MODULE_DIR = path.join(ROOT, 'module');
const DIST_DIR = path.join(ROOT, 'dist');

// 这些必须是可执行文件，否则部分 recovery 里跑不起来
const EXECUTABLES = new Set([
  'META-INF/com/google/android/update-binary',
  'customize.sh',
  'service.sh',
  'post-fs-data.sh',
  'action.sh',
  'uninstall.sh',
]);

function readVersion() {
  try {
    const prop = fs.readFileSync(path.join(MODULE_DIR, 'module.prop'), 'utf8');
    const m = prop.match(/^version=(.+)$/m);
    return m ? m[1].trim() : 'v1.0';
  } catch {
    return 'v1.0';
  }
}

function main() {
  const args = process.argv.slice(2);
  const outIdx = args.indexOf('--out');
  const outPath = outIdx >= 0 ? args[outIdx + 1] : null;
  const apkPath = args.find((a) => !a.startsWith('--') && a !== outPath);

  if (!fs.existsSync(MODULE_DIR)) {
    console.error('找不到 module/ 目录');
    process.exit(1);
  }

  const entries = collect(MODULE_DIR).map((entry) => ({
    ...entry,
    mode: EXECUTABLES.has(entry.name) ? 0o755 : 0o644,
  }));

  let apkInfo = '未包含 APK（刷入后不会出现小人）';
  if (apkPath) {
    const abs = path.resolve(apkPath);
    if (!fs.existsSync(abs)) {
      console.error(`APK 不存在: ${abs}`);
      process.exit(1);
    }
    const data = fs.readFileSync(abs);
    const isZip = data.length > 4 && data.readUInt32LE(0) === 0x04034b50;
    const hasManifest = data.includes(Buffer.from('AndroidManifest.xml', 'latin1'));
    if (!isZip || !hasManifest) {
      console.error(`不像一个 APK: ${abs}`);
      process.exit(1);
    }
    entries.push({
      name: 'apk/pet.apk',
      data,
      mtime: fs.statSync(abs).mtime,
      mode: 0o644,
    });
    apkInfo = `${path.basename(abs)} (${(data.length / 1024 / 1024).toFixed(2)} MB)`;
  }

  // META-INF 放最前，个别老 recovery 会先找它
  entries.sort((a, b) => {
    const rank = (n) => (n.startsWith('META-INF/') ? 0 : n === 'module.prop' ? 1 : 2);
    return rank(a.name) - rank(b.name) || a.name.localeCompare(b.name);
  });

  const zip = buildZip(entries);
  const version = readVersion();
  fs.mkdirSync(DIST_DIR, { recursive: true });
  const target = outPath
    ? path.resolve(outPath)
    : path.join(DIST_DIR, `screen_pet-${version}.zip`);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, zip);

  console.log(`已生成: ${target}`);
  console.log(`  文件数: ${entries.length}`);
  console.log(`  体积:   ${(zip.length / 1024).toFixed(1)} KB`);
  console.log(`  APK:    ${apkInfo}`);
}

main();
