# 屏幕小人 · KernelSU 模块

刷入后屏幕上出现一个小人：会自己到处走，走到屏幕边缘会黏上去沿边框爬，点它会跳一下并且笑，按住可以拖到任意位置。

## 结构

```
module/                       模块内容（整个目录会被打进 zip）
├── module.prop               模块信息（id / 名字 / 版本）
├── customize.sh              刷入时的检查
├── post-fs-data.sh           开机极早期：清日志
├── service.sh                开机完成：装 APK、授权限、拉起
├── action.sh                 KernelSU 管理器「操作」按钮：一键开关
├── uninstall.sh              卸载时收尾
├── apk/pet.apk               放编译好的小人 APK（打包时自动放入）
└── META-INF/                 安装器（Magisk 官方那份）

android/                      App 工程（Gradle，纯 Java，无第三方依赖）
└── app/src/main/java/com/dsh/pet/
    ├── LauncherActivity.java 检查权限 → 拉服务 → 立刻结束
    ├── PetService.java       悬浮窗位置、走动、贴边、拖拽的状态机
    └── PetView.java          小人的画与手势

tools/build-module.js         打包脚本（纯 Node，不依赖 zip 命令）
.github/workflows/build.yml   推上去自动出 APK + 模块 zip
```

## 为什么模块里要装一个 APK

KSU 模块只是「文件 + 开机脚本」，本身没有画屏幕的能力。屏幕上的东西必须有窗口，而窗口要有悬浮窗权限。所以是：

```
刷模块 → service.sh 开机跑 → pm install 内置 APK
       → appops 直接授予 SYSTEM_ALERT_WINDOW
       → am start 拉起前台服务 → 悬浮窗画出小人
```

这条链路让用户不用手动装 App、不用手动点授权，刷完重启就出现。

## 三步

### 1. 编 APK

**Google Colab（纯手机首选）**：打开 [colab.research.google.com](https://colab.research.google.com)，上传 [colab/build.ipynb](colab/build.ipynb)，再上传 `dist/pet-module-src.zip`，然后从上到下跑完所有格子。最后那一格会直接把 `screen_pet-v1.0.zip` 下载到手机，**连第 2 步的打包都省了**。

**GitHub Actions（不用装任何东西）**：把本目录推到 GitHub，Actions 里 `build-module` 会自动编 APK、打模块 zip，直接下 artifact。

**手机上（AndroidIDE）**：装 [AndroidIDE](https://github.com/AndroidIDEOfficial/AndroidIDE)，打开本目录的 `android/`，等它同步完，Build → Assemble Debug，产物在 `android/app/build/outputs/apk/debug/app-debug.apk`。


### 2. 打包模块

```sh
node tools/build-module.js android/app/build/outputs/apk/debug/app-debug.apk
# → dist/screen_pet-v1.0.zip
```

脚本会检查 APK 是不是真的 APK、把脚本权限写成 755、其余 644，输出一份标准 Magisk/KSU 模块 zip。

### 3. 刷入

KernelSU 管理器 → 模块 → 从本地安装 → 选 `dist/screen_pet-v1.0.zip` → 重启。

不用重启也可以：刷完在管理器里点模块的「操作」按钮，等于执行 `action.sh`，小人立刻上场。

## 刷完之后

| 动作 | 结果 |
| --- | --- |
| 放着不动 | 站一会儿，然后挑一个目标走；45% 概率直奔某条边框 |
| 走到边缘 | 黏上去，双手上举，沿边框慢慢挪 2.5～7 秒再下来 |
| 点一下 | 跳起来，眼睛变成 `> <`，张嘴；如果正黏在边上会直接跳下来 |
| 按住拖 | 跟手移动，松手时如果靠边就顺手吸附上去 |

KernelSU 管理器的「操作」按钮是开关：运行中点了就停，停着点了就拉起。

## 想改

- 速度：`PetService.java` 里 `speedPx = dp(1.7f)`，数字大了走得快
- 大小：同文件 `petW = dp(84)`、`petH = dp(104)`
- 贴边概率：`chooseTarget()` 里 `random.nextInt(100) < 45`
- 颜色：`PetView` 构造函数里的 `0xFF4FC3F7`（衣服）、`0xFFFFDDB3`（皮肤）
- 脸和走路姿势：`PetView.onDraw()`

## 排错

日志统一在 `/data/local/tmp/screen_pet.log`（每次开机会清空）：

```sh
su -c 'cat /data/local/tmp/screen_pet.log'        # 看开机都干了什么
su -c 'appops get com.dsh.pet SYSTEM_ALERT_WINDOW' # 悬浮窗权限
su -c 'pm path com.dsh.pet'                        # APK 装没装上
su -c 'pidof com.dsh.pet'                          # 进程在不在
```

小人没出现，按顺序查：

1. 日志里有没有「缺少 apk/pet.apk」→ 打包时漏了 APK
2. `pm path` 没输出 → `pm install` 失败，看日志里的报错
3. `appops get` 不是 `allow` → 手动 `su -c 'appops set com.dsh.pet SYSTEM_ALERT_WINDOW allow'`
4. 进程在但看不见 → 检查系统设置里「屏幕小人」的悬浮窗开关是否被 ROM 单独关掉
5. 一会就消失 → 后台被杀了，`dumpsys deviceidle whitelist` 已在开机时加白名单；ColorOS 还要在「电池 → 应用耗电管理」里给「屏幕小人」设为不限制

## 卸载

管理器里卸载模块即可，`uninstall.sh` 会停进程、收回悬浮窗权限、删日志。APK 故意留着（避免误删），要彻底清干净：

```sh
su -c 'pm uninstall com.dsh.pet'
```

## 已知边界

- 需要 Android 8.0+；Android 14+ 前台服务必须声明类型，工程里已用 `specialUse`
- 小人是**一个悬浮窗**，只在自己那块矩形里接收触摸；窗口之外的屏幕触摸不受影响
- 走动是每帧改窗口坐标实现的，30fps，耗电很低但确实在跑（有常驻通知，系统要求如此）
- 第一次开机可能比系统 App 晚几秒出现，`service.sh` 里等了 8 秒
