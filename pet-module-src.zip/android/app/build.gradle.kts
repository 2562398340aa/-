plugins {
    id("com.android.application")
}

android {
    namespace = "com.dsh.pet"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dsh.pet"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
            // 模块用的 APK 用 debug 签名即可，系统只要求签名一致
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
    }
}
