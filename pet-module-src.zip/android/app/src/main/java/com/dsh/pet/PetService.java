package com.dsh.pet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import java.util.Random;

/**
 * 周 —— 行为层。
 *
 * 位置 = 每帧改悬浮窗坐标；说话 = 第二个「气泡」悬浮窗（不可触摸，跟在小人上方）。
 * 行为：走动 / 贴边 / 睡觉 / 打哈欠 / 玩手机 / 抽烟，点击则蹦跳或被打并说话。
 */
public class PetService extends Service implements PetView.Host {

    private static final int LEFT = 1;
    private static final int RIGHT = 2;
    private static final int TOP = 3;
    private static final int BOTTOM = 4;

    private static final long FRAME_MS = 16L;   // 60fps，动作才不卡顿
    private static final int NOTIFY_ID = 4711;

    private static final String[] TAP_LINES = {"干嘛", "别戳了", "嗯？", "嘿嘿", "有事？", "再戳我生气了"};
    private static final String[] HIT_LINES = {"哎哟！", "疼疼疼", "你打我", "过分了", "记仇了", "轻点啊"};
    private static final String[] SLEEP_LINES = {"zZZ…", "别吵我"};
    private static final String[] WAKE_LINES = {"困…", "被你吵醒了", "嗯…几点了"};
    private static final String[] YAWN_LINES = {"好困啊", "啊——", "睡不够"};
    private static final String[] PHONE_LINES = {"刷会儿手机", "这个好看", "再玩五分钟", "等下就睡"};
    private static final String[] SMOKE_LINES = {"来一根", "呼——", "歇会儿", "烦"};
    private static final String[] WALK_LINES = {"溜达溜达", "我走走", "今天还行"};

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private PetView pet;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleLp;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private int screenW, screenH, petW, petH, topInset, edgeMargin;
    private float speedPx;

    private boolean walking;
    private boolean dragging;
    private int clingSide;
    private int slideDir = 1;
    private long clingUntil;
    private long idleUntil;
    private long activityEnd;      // >0 表示正在做休闲动作
    private int activityState = -1;
    private int pendingCling;
    private float targetX, targetY;
    private float speedRamp;
    private long lastFrame;
    private boolean attached;

    private float dragX, dragY;    // 拖拽目标（阻尼跟随）

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            if (!attached) return;
            tickFrame();
            handler.postDelayed(this, FRAME_MS);
        }
    };

    private final Runnable hideBubble = new Runnable() {
        @Override
        public void run() {
            if (bubble != null) {
                try {
                    wm.removeView(bubble);
                } catch (Exception ignored) {
                }
                bubble = null;
            }
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIFY_ID, buildNotification());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        petW = dp(96);
        petH = dp(122);
        speedPx = dp(1.9f);
        edgeMargin = dp(30);
        updateMetrics();

        pet = new PetView(this);
        pet.setHost(this);

        lp = new WindowManager.LayoutParams(
                petW, petH,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = random.nextInt(Math.max(1, screenW - petW));
        lp.y = Math.max(topInset, (screenH - petH) / 2);

        try {
            wm.addView(pet, lp);
            attached = true;
        } catch (Exception e) {
            stopSelf();
            return;
        }

        idleUntil = SystemClock.uptimeMillis() + 1500;
        handler.postDelayed(frame, FRAME_MS);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateMetrics();
        clampLayout();
        applyLayout();
    }

    @Override
    public void onDestroy() {
        attached = false;
        handler.removeCallbacks(frame);
        handler.removeCallbacks(hideBubble);
        if (bubble != null && wm != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
        if (pet != null && wm != null) {
            try {
                wm.removeView(pet);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- 每帧

    private void tickFrame() {
        final long now = SystemClock.uptimeMillis();
        final float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;

        pet.tick(dt);
        pet.invalidate();

        if (dragging) {
            // 阻尼跟手：位置追目标，身体按速度倾斜
            final float k = Math.min(1f, dt * 16f);
            final float vx = dragX - lp.x;
            final float vy = dragY - lp.y;
            lp.x += vx * k;
            lp.y += vy * k;
            pet.setLean(clamp(vx * 0.10f, -15f, 15f));
            clampLayout();
            applyLayout();
            return;
        }

        // 休闲动作进行中
        if (activityEnd > 0) {
            if (now >= activityEnd) endActivity(now);
            else return;
        }

        if (clingSide != 0) {
            if (now >= clingUntil) {
                releaseCling(now);
                return;
            }
            final float step = speedPx * 60f * dt * 0.35f;
            if (clingSide == LEFT || clingSide == RIGHT) {
                lp.y += slideDir * step;
                clampY();
            } else {
                lp.x += slideDir * step;
                clampX();
            }
            applyLayout();
            return;
        }

        if (!walking) {
            if (now >= idleUntil) decide(now);
            return;
        }

        // 走路：起步加速、临近减速，避免“瞬间启动”的僵硬感
        speedRamp = Math.min(1f, speedRamp + dt * 2.6f);
        final float dx = targetX - lp.x;
        final float dy = targetY - lp.y;
        final float dist = (float) Math.hypot(dx, dy);
        final float slowDown = Math.min(1f, dist / Math.max(1f, speedPx * 10f));
        final float step = speedPx * 60f * dt * speedRamp * (0.35f + 0.65f * slowDown);

        if (dist <= Math.max(1.5f, step * 0.9f)) {
            lp.x = Math.round(targetX);
            lp.y = Math.round(targetY);
            clampLayout();
            arrive(now);
            applyLayout();
            return;
        }

        lp.x += dx / dist * step;
        lp.y += dy / dist * step;
        if (Math.abs(dx) > 1.5f) pet.setFacing(dx > 0 ? 1 : -1);
        clampLayout();
        applyLayout();
    }

    /** 空闲结束：决定下一步做什么。 */
    private void decide(long now) {
        final int roll = random.nextInt(100);

        if (roll < 34) {
            chooseWalkTarget();
            if (random.nextInt(100) < 12) say(pick(WALK_LINES));
            return;
        }

        // 其余时间做点休闲的事
        final int pickRoll = random.nextInt(100);
        if (pickRoll < 24) {
            startActivity(PetView.SLEEP, 12f + random.nextInt(14), SLEEP_LINES);
        } else if (pickRoll < 46) {
            startActivity(PetView.YAWN, 3.2f, YAWN_LINES);
        } else if (pickRoll < 80) {
            startActivity(PetView.PHONE, 6f + random.nextInt(9), PHONE_LINES);
        } else {
            startActivity(PetView.SMOKE, 8f + random.nextInt(9), SMOKE_LINES);
        }
    }

    private void startActivity(int state, float seconds, String[] lines) {
        activityState = state;
        activityEnd = SystemClock.uptimeMillis() + (long) (seconds * 1000f);
        walking = false;
        clingSide = 0;
        pet.startActivity(state, seconds);
        if (random.nextInt(100) < 55) say(pick(lines));
    }

    private void endActivity(long now) {
        activityEnd = 0;
        activityState = -1;
        pet.setState(PetView.IDLE);
        idleUntil = now + 900 + random.nextInt(1600);
    }

    private void chooseWalkTarget() {
        walking = true;
        speedRamp = 0f;
        idleUntil = 0;
        pet.setState(PetView.WALK);

        if (random.nextInt(100) < 45) {
            final int side = 1 + random.nextInt(4);
            pendingCling = side;
            switch (side) {
                case LEFT:
                    targetX = 0;
                    targetY = randY();
                    break;
                case RIGHT:
                    targetX = screenW - petW;
                    targetY = randY();
                    break;
                case TOP:
                    targetX = randX();
                    targetY = topInset;
                    break;
                default:
                    targetX = randX();
                    targetY = screenH - petH;
                    break;
            }
        } else {
            pendingCling = 0;
            targetX = randX();
            targetY = randY();
        }
    }

    private void arrive(long now) {
        walking = false;
        if (pendingCling != 0) {
            clingSide = pendingCling;
            pendingCling = 0;
            snapToEdge(clingSide);
            clampLayout();
            slideDir = random.nextBoolean() ? 1 : -1;
            clingUntil = now + 2500 + random.nextInt(4500);
            pet.setState(PetView.CLING);
        } else {
            idleUntil = now + 900 + random.nextInt(1800);
            pet.setState(PetView.IDLE);
        }
    }

    private void releaseCling(long now) {
        clingSide = 0;
        walking = false;
        idleUntil = now + 500 + random.nextInt(1200);
        pet.setState(PetView.IDLE);
    }

    private void snapToEdge(int side) {
        switch (side) {
            case LEFT:
                lp.x = 0;
                break;
            case RIGHT:
                lp.x = screenW - petW;
                break;
            case TOP:
                lp.y = topInset;
                break;
            default:
                lp.y = screenH - petH;
                break;
        }
    }

    private int nearEdge() {
        if (lp.x <= edgeMargin) return LEFT;
        if (lp.x + petW >= screenW - edgeMargin) return RIGHT;
        if (lp.y <= topInset + edgeMargin) return TOP;
        if (lp.y + petH >= screenH - edgeMargin) return BOTTOM;
        return 0;
    }

    // ---------------------------------------------------------------- 手势

    @Override
    public void onDragStart() {
        dragging = true;
        walking = false;
        clingSide = 0;
        pendingCling = 0;
        activityEnd = 0;
        activityState = -1;
        dragX = lp.x;
        dragY = lp.y;
        pet.setState(PetView.DRAG);
    }

    @Override
    public void onDragBy(float dx, float dy) {
        // 只更新目标，实际位置在 tickFrame 里阻尼跟随
        dragX += dx;
        dragY += dy;
        dragX = Math.max(0, Math.min(screenW - petW, dragX));
        dragY = Math.max(topInset, Math.min(screenH - petH, dragY));
    }

    @Override
    public void onDragEnd() {
        dragging = false;
        pet.setLean(0f);
        final long now = SystemClock.uptimeMillis();
        final int side = nearEdge();
        if (side != 0) {
            clingSide = side;
            snapToEdge(side);
            clampLayout();
            applyLayout();
            slideDir = random.nextBoolean() ? 1 : -1;
            clingUntil = now + 2000 + random.nextInt(3000);
            pet.setState(PetView.CLING);
        } else {
            idleUntil = now + 400 + random.nextInt(700);
            pet.setState(PetView.IDLE);
        }
    }

    @Override
    public void onPetTap() {
        final long now = SystemClock.uptimeMillis();

        if (activityState == PetView.SLEEP) {
            activityEnd = 0;
            activityState = -1;
            pet.wake();
            pet.setState(PetView.IDLE);
            say(pick(WAKE_LINES));
            idleUntil = now + 700;
            return;
        }

        if (activityEnd > 0) {
            activityEnd = 0;
            activityState = -1;
        }
        walking = false;
        clingSide = 0;

        if (random.nextBoolean()) {
            pet.jump();
            say(pick(TAP_LINES));
        } else {
            pet.hit();
            say(pick(HIT_LINES));
        }
        idleUntil = now + 1100;
    }

    // ---------------------------------------------------------------- 说话

    private void say(String text) {
        if (bubble == null) {
            bubble = new TextView(this);
            final GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF5FFFFFF);
            bg.setCornerRadius(dp(12));
            bg.setStroke(dp(1), 0x33241F1F);
            bubble.setBackground(bg);
            bubble.setTextColor(0xFF241F1F);
            bubble.setTextSize(13f);
            bubble.setPadding(dp(10), dp(7), dp(10), dp(7));
            bubble.setMaxLines(3);

            bubbleLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            bubbleLp.gravity = Gravity.TOP | Gravity.START;
            try {
                wm.addView(bubble, bubbleLp);
            } catch (Exception e) {
                bubble = null;
                return;
            }
        }

        bubble.setText(text);
        moveBubble();
        handler.removeCallbacks(hideBubble);
        handler.postDelayed(hideBubble, 2800);
    }

    private void moveBubble() {
        if (bubble == null) return;
        bubble.post(new Runnable() {
            @Override
            public void run() {
                if (bubble == null) return;
                final int bw = bubble.getWidth();
                final int bh = bubble.getHeight();
                if (bw <= 0 || bh <= 0) return;
                bubbleLp.x = Math.max(0, Math.min(screenW - bw, lp.x + petW / 2 - bw / 2));
                bubbleLp.y = Math.max(topInset + dp(2), lp.y - bh - dp(6));
                try {
                    wm.updateViewLayout(bubble, bubbleLp);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private String pick(String[] pool) {
        return pool[random.nextInt(pool.length)];
    }

    // ---------------------------------------------------------------- 杂项

    private void applyLayout() {
        if (!attached) return;
        try {
            wm.updateViewLayout(pet, lp);
        } catch (Exception ignored) {
        }
        if (bubble != null) moveBubble();
    }

    private void clampLayout() {
        clampX();
        clampY();
    }

    private void clampX() {
        if (lp.x < 0) lp.x = 0;
        if (lp.x > screenW - petW) lp.x = screenW - petW;
    }

    private void clampY() {
        if (lp.y < topInset) lp.y = topInset;
        if (lp.y > screenH - petH) lp.y = screenH - petH;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private float randX() {
        return random.nextInt(Math.max(1, screenW - petW));
    }

    private float randY() {
        return topInset + random.nextInt(Math.max(1, screenH - petH - topInset));
    }

    private void updateMetrics() {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        topInset = statusBarHeight();
    }

    private int statusBarHeight() {
        final int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(28);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private Notification buildNotification() {
        final String channel = "screen_pet";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            final NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(channel) == null) {
                final NotificationChannel c = new NotificationChannel(
                        channel, "周", NotificationManager.IMPORTANCE_LOW);
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
        }

        final Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);

        b.setContentTitle("周")
                .setContentText("周正在屏幕上转悠")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true);
        return b.build();
    }
}
