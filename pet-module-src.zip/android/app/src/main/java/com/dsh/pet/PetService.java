package com.dsh.pet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import java.util.Random;

/**
 * 悬浮窗宿主：负责小人的位置、走动、贴边、拖拽，以及每帧重绘。
 *
 * 走动 = 每帧修改 WindowManager.LayoutParams 的 x/y 后 updateViewLayout，
 * 这是悬浮窗唯一靠谱的移动方式（小人本身不是一个能自绘全屏的窗口）。
 */
public class PetService extends Service implements PetView.Host {

    private static final int LEFT = 1;
    private static final int RIGHT = 2;
    private static final int TOP = 3;
    private static final int BOTTOM = 4;

    private static final long FRAME_MS = 33L;   // ~30fps
    private static final int NOTIFY_ID = 4711;

    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private PetView pet;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private int screenW, screenH, petW, petH, topInset;
    private float speedPx;

    private float targetX, targetY;
    private boolean walking;
    private long idleUntil;
    private int pendingCling;
    private int clingSide;
    private int slideDir = 1;
    private long clingUntil;
    private boolean dragging;
    private long lastFrame;
    private boolean attached;

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            if (!attached) return;
            tickFrame();
            handler.postDelayed(this, FRAME_MS);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIFY_ID, buildNotification());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        petW = dp(84);
        petH = dp(104);
        speedPx = dp(1.7f);
        updateMetrics();

        pet = new PetView(this);
        pet.setHost(this);

        lp = new WindowManager.LayoutParams(
                petW, petH,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = random.nextInt(Math.max(1, screenW - petW));
        lp.y = Math.max(topInset, (screenH - petH) / 2);

        try {
            wm.addView(pet, lp);
            attached = true;
        } catch (Exception e) {
            // 没有悬浮窗权限时会到这里：直接收摊，避免留下一个空通知
            stopSelf();
            return;
        }

        idleUntil = SystemClock.uptimeMillis() + 1500;
        handler.postDelayed(frame, FRAME_MS);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateMetrics();
        clampLayout();
        applyLayout();
    }

    @Override
    public void onDestroy() {
        attached = false;
        handler.removeCallbacks(frame);
        if (pet != null && wm != null) {
            try {
                wm.removeView(pet);
            } catch (Exception ignored) {
                // 已经被系统移除了
            }
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- 每帧

    private void tickFrame() {
        final long now = SystemClock.uptimeMillis();
        final float dt = lastFrame == 0
                ? 0.033f
                : Math.min(0.08f, (now - lastFrame) / 1000f);
        lastFrame = now;

        pet.tick(dt);
        pet.invalidate();

        if (dragging) return;

        final float step = speedPx * 60f * dt;

        if (clingSide != 0) {
            if (now >= clingUntil) {
                releaseCling(now);
                return;
            }
            // 贴边时沿边慢慢挪，像在边框上爬
            if (clingSide == LEFT || clingSide == RIGHT) {
                lp.y += slideDir * step * 0.45f;
                clampY();
            } else {
                lp.x += slideDir * step * 0.45f;
                clampX();
            }
            applyLayout();
            return;
        }

        if (!walking) {
            if (now >= idleUntil) chooseTarget();
            return;
        }

        final float dx = targetX - lp.x;
        final float dy = targetY - lp.y;
        final float dist = (float) Math.hypot(dx, dy);

        if (dist <= step || dist < 1.5f) {
            lp.x = Math.round(targetX);
            lp.y = Math.round(targetY);
            clampLayout();
            arrive(now);
            applyLayout();
            return;
        }

        lp.x += dx / dist * step;
        lp.y += dy / dist * step;
        if (Math.abs(dx) > 1.5f) pet.setFacing(dx > 0 ? 1 : -1);
        clampLayout();
        applyLayout();
    }

    private void chooseTarget() {
        walking = true;
        pet.setState(PetView.STATE_WALK);

        if (random.nextInt(100) < 45) {
            // 45% 的概率直奔某条边框
            final int side = 1 + random.nextInt(4);
            pendingCling = side;
            switch (side) {
                case LEFT:
                    targetX = 0;
                    targetY = randY();
                    break;
                case RIGHT:
                    targetX = screenW - petW;
                    targetY = randY();
                    break;
                case TOP:
                    targetX = randX();
                    targetY = topInset;
                    break;
                default:
                    targetX = randX();
                    targetY = screenH - petH;
                    break;
            }
        } else {
            pendingCling = 0;
            targetX = randX();
            targetY = randY();
        }
    }

    private void arrive(long now) {
        walking = false;
        if (pendingCling != 0) {
            clingSide = pendingCling;
            pendingCling = 0;
            snapToEdge(clingSide);
            clampLayout();
            slideDir = random.nextBoolean() ? 1 : -1;
            clingUntil = now + 2500 + random.nextInt(4500);
            pet.setState(PetView.STATE_CLING);
        } else {
            idleUntil = now + 700 + random.nextInt(1800);
            pet.setState(PetView.STATE_IDLE);
        }
    }

    private void releaseCling(long now) {
        clingSide = 0;
        walking = false;
        idleUntil = now + 400 + random.nextInt(1000);
        pet.setState(PetView.STATE_IDLE);
    }

    private void snapToEdge(int side) {
        switch (side) {
            case LEFT:
                lp.x = 0;
                break;
            case RIGHT:
                lp.x = screenW - petW;
                break;
            case TOP:
                lp.y = topInset;
                break;
            default:
                lp.y = screenH - petH;
                break;
        }
    }

    private int nearEdge() {
        final int margin = dp(28);
        if (lp.x <= margin) return LEFT;
        if (lp.x + petW >= screenW - margin) return RIGHT;
        if (lp.y <= topInset + margin) return TOP;
        if (lp.y + petH >= screenH - margin) return BOTTOM;
        return 0;
    }

    // ---------------------------------------------------------------- 手势

    @Override
    public void onDragStart() {
        dragging = true;
        walking = false;
        clingSide = 0;
        pendingCling = 0;
        pet.setState(PetView.STATE_DRAG);
    }

    @Override
    public void onDragBy(float dx, float dy) {
        lp.x += Math.round(dx);
        lp.y += Math.round(dy);
        clampLayout();
        applyLayout();
    }

    @Override
    public void onDragEnd() {
        dragging = false;
        final long now = SystemClock.uptimeMillis();
        final int side = nearEdge();
        if (side != 0) {
            // 松手时靠边就顺手黏上去
            clingSide = side;
            snapToEdge(side);
            clampLayout();
            applyLayout();
            slideDir = random.nextBoolean() ? 1 : -1;
            clingUntil = now + 2000 + random.nextInt(3000);
            pet.setState(PetView.STATE_CLING);
        } else {
            idleUntil = now + 300 + random.nextInt(700);
            pet.setState(PetView.STATE_IDLE);
        }
    }

    @Override
    public void onPetTap() {
        pet.react();
        final long now = SystemClock.uptimeMillis();
        if (clingSide != 0) {
            // 戳一下就从边上跳下来
            releaseCling(now);
        } else if (!walking) {
            idleUntil = now + 900 + random.nextInt(800);
        }
    }

    // ---------------------------------------------------------------- 杂项

    private void applyLayout() {
        if (!attached) return;
        try {
            wm.updateViewLayout(pet, lp);
        } catch (Exception ignored) {
            // 窗口已被系统回收
        }
    }

    private void clampLayout() {
        clampX();
        clampY();
    }

    private void clampX() {
        if (lp.x < 0) lp.x = 0;
        if (lp.x > screenW - petW) lp.x = screenW - petW;
    }

    private void clampY() {
        if (lp.y < topInset) lp.y = topInset;
        if (lp.y > screenH - petH) lp.y = screenH - petH;
    }

    private float randX() {
        return random.nextInt(Math.max(1, screenW - petW));
    }

    private float randY() {
        return topInset + random.nextInt(Math.max(1, screenH - petH - topInset));
    }

    private void updateMetrics() {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        topInset = statusBarHeight();
    }

    private int statusBarHeight() {
        final int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(28);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private Notification buildNotification() {
        final String channel = "screen_pet";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            final NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(channel) == null) {
                final NotificationChannel c = new NotificationChannel(
                        channel, "屏幕小人", NotificationManager.IMPORTANCE_LOW);
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
        }

        final Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);

        b.setContentTitle("屏幕小人")
                .setContentText("小人正在屏幕上散步")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true);
        return b.build();
    }
}
