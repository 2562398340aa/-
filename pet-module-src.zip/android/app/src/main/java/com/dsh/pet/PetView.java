package com.dsh.pet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.Random;

/**
 * 周 —— 小人的全部绘制与手势。
 *
 * 画法是 Q 版两段式：腿有膝盖、手臂有手肘，所以走路不是两根棍子摆，而是有折叠和起伏。
 * 状态：站立 / 走路 / 贴边 / 被拖 / 睡觉 / 打哈欠 / 玩手机 / 抽烟 / 蹦跳 / 被砸。
 * 没有任何图片资源，全部 Canvas 绘制。
 */
public class PetView extends View {

    public static final int IDLE = 0;
    public static final int WALK = 1;
    public static final int CLING = 2;
    public static final int DRAG = 3;
    public static final int SLEEP = 4;
    public static final int YAWN = 5;
    public static final int PHONE = 6;
    public static final int SMOKE = 7;
    public static final int JUMP = 8;
    public static final int HIT = 9;

    private static final int C_SKIN = 0xFFFFD9B6;
    private static final int C_SKIN_SHADE = 0xFFEFC09B;
    private static final int C_HAIR = 0xFF352926;
    private static final int C_HAIR_HI = 0xFF63443C;
    private static final int C_SHIRT = 0xFF7EC8E3;
    private static final int C_SHIRT_DARK = 0xFF4E9CBC;
    private static final int C_PANTS = 0xFF46525E;
    private static final int C_SHOE = 0xFF2A3138;
    private static final int C_INK = 0xFF241F1F;
    private static final int C_WHITE = 0xFFFFFFFF;
    private static final int C_BLUSH = 0x5CFF7B7B;
    private static final int C_OUTLINE = 0xB0241F1F;
    private static final int C_PHONE = 0xFF2B2B2B;
    private static final int C_PHONE_LIGHT = 0xFF9BE3FF;
    private static final int C_PAPER = 0xFFF2F2F2;
    private static final int C_EMBER = 0xFFFF8A3D;

    public interface Host {
        void onDragStart();

        void onDragBy(float dx, float dy);

        void onDragEnd();

        void onPetTap();
    }

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Path path = new Path();
    private final Random random = new Random();
    private final float density;

    private Host host;
    private int state = IDLE;
    private int facing = 1;

    private float phase;        // 步态相位
    private float breathe;      // 呼吸
    private float blink = 1f;   // 1 睁 0 闭
    private float blinkWait = 2.4f;
    private float jaw;          // 嘴张开程度 0..1
    private float jawWait = 3.5f;
    private float jump;         // 1 → 0
    private float hit;          // 1 → 0
    private float lean;         // 拖拽倾角
    private float activityT;    // 当前休闲动作进度 0..1
    private float activityDur = 1f;

    private float downX, downY, lastX, lastY;
    private boolean dragging;
    private final int slop;

    public PetView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        soft.setStyle(Paint.Style.FILL);
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public void setState(int newState) {
        if (state != newState) {
            state = newState;
            if (newState != WALK) phase = 0f;
            if (newState == IDLE) activityT = 0f;
            invalidate();
        }
    }

    public void setFacing(int direction) {
        facing = direction >= 0 ? 1 : -1;
    }

    /** 拖拽时身体前倾的角度（度）。 */
    public void setLean(float degrees) {
        lean = degrees;
    }

    /** 开始一个持续时间固定的休闲动作。 */
    public void startActivity(int newState, float seconds) {
        state = newState;
        activityT = 0f;
        activityDur = Math.max(0.5f, seconds);
        phase = 0f;
        invalidate();
    }

    public void jump() {
        jump = 1f;
        jaw = 1f;
        invalidate();
    }

    public void hit() {
        hit = 1f;
        jaw = 1f;
        invalidate();
    }

    public void wake() {
        jaw = 1f;
        invalidate();
    }

    public void tick(float dt) {
        breathe += dt * 1.9f;
        if (state == WALK) phase += dt * 7.2f;
        if (activityT < 1f && activityDur > 0f) {
            activityT = Math.min(1f, activityT + dt / activityDur);
        }

        // 眨眼
        blinkWait -= dt;
        if (blinkWait <= 0f) {
            blinkWait = 2.0f + random.nextFloat() * 3.6f;
            blink = 0f;
        }
        blink = Math.min(1f, blink + dt * 9f);

        // 偶尔张嘴（像在嘟囔）
        jawWait -= dt;
        if (jawWait <= 0f) {
            jawWait = 4f + random.nextFloat() * 6f;
            jaw = 1f;
        }
        jaw = Math.max(0f, jaw - dt * 2.2f);

        if (jump > 0f) jump = Math.max(0f, jump - dt * 1.25f);
        if (hit > 0f) hit = Math.max(0f, hit - dt * 1.1f);
    }

    private float dp(float v) {
        return v * density;
    }

    // ---------------------------------------------------------------- 主绘制

    @Override
    protected void onDraw(Canvas canvas) {
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        final float cx = w / 2f;
        final float ground = h * 0.95f;

        // 影子：始终贴地，不参与任何变形
        soft.setColor(0x22000000);
        oval.set(cx - w * 0.20f, ground - h * 0.012f, cx + w * 0.20f, ground + h * 0.020f);
        canvas.drawOval(oval, soft);

        canvas.save();

        // 被砸：抖动 + 压扁
        if (hit > 0.01f) {
            final float shake = (float) Math.sin(hit * 46f) * dp(3.4f) * hit;
            canvas.translate(shake, 0f);
            final float sx = 1f + 0.16f * hit;
            final float sy = 1f - 0.16f * hit;
            canvas.scale(sx, sy, cx, ground);
        }

        // 被拖：整体倾斜
        if (Math.abs(lean) > 0.1f) canvas.rotate(lean, cx, ground);

        // 蹦跳：整体离地
        float lift = 0f;
        if (jump > 0.01f) lift = (float) Math.sin(jump * Math.PI) * h * 0.11f;
        if (hit > 0.01f) lift += (float) Math.sin(hit * Math.PI) * h * 0.02f;

        // 走路时的上下起伏
        float bob = 0f;
        if (state == WALK) bob = (float) Math.sin(phase * 2f) * h * 0.012f;
        else if (state == IDLE) bob = (float) Math.sin(breathe) * h * 0.006f;

        canvas.translate(0f, bob - lift);

        drawFigure(canvas, w, h, cx, ground);

        canvas.restore();

        // 特效（不受身体变形影响）
        if (hit > 0.2f) drawDizzy(canvas, cx, h);
        if (jump > 0.2f) drawHearts(canvas, cx, h);
        if (state == SLEEP) drawZzz(canvas, w, h);
        if (state == SMOKE) drawSmoke(canvas, w, h);
    }

    private void drawFigure(Canvas canvas, float w, float h, float cx, float ground) {
        final float headR = w * 0.255f;
        final float headCy = h * 0.285f;
        final float neckY = headCy + headR * 0.92f;
        final float hipY = h * 0.735f;
        final float bodyW = w * 0.38f;
        final float shoulderY = neckY + (hipY - neckY) * 0.12f;
        final float bodyH = hipY - neckY;

        // 睡觉时整体下沉一点
        final float slump = state == SLEEP ? h * 0.012f : 0f;

        // ---- 腿（两段：髋→膝→踝）
        final float hipL = cx - bodyW * 0.22f;
        final float hipR = cx + bodyW * 0.22f;
        final float legW = w * 0.105f;

        float swing = 0f;
        if (state == WALK) swing = (float) Math.sin(phase) * w * 0.115f;

        if (state == DRAG || state == CLING) {
            // 悬空：腿自然下垂带一点摆
            float dangle = (float) Math.sin(breathe * 2.1f) * w * 0.02f;
            legTwo(canvas, hipL, hipY, cx - bodyW * 0.26f + dangle, hipY + bodyH * 0.22f,
                    cx - bodyW * 0.22f + dangle * 1.4f, ground - h * 0.015f, legW);
            legTwo(canvas, hipR, hipY, cx + bodyW * 0.26f - dangle, hipY + bodyH * 0.22f,
                    cx + bodyW * 0.22f - dangle * 1.4f, ground - h * 0.015f, legW);
        } else {
            legTwo(canvas, hipL, hipY, hipL + swing * 0.5f, (hipY + ground) * 0.5f + slump,
                    hipL + swing, ground - h * 0.015f, legW);
            legTwo(canvas, hipR, hipY, hipR - swing * 0.5f, (hipY + ground) * 0.5f + slump,
                    hipR - swing, ground - h * 0.015f, legW);
        }

        // 鞋
        shoe(canvas, hipL + swing, ground - h * 0.015f + slump, w * 0.125f);
        shoe(canvas, hipR - swing, ground - h * 0.015f + slump, w * 0.125f);

        // ---- 身体
        oval.set(cx - bodyW / 2f, shoulderY + slump, cx + bodyW / 2f, hipY + h * 0.010f + slump);
        fill.setColor(C_SHIRT);
        canvas.drawRoundRect(oval, bodyW * 0.36f, bodyW * 0.36f, fill);
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(dp(1.3f));
        canvas.drawRoundRect(oval, bodyW * 0.36f, bodyW * 0.36f, stroke);

        // 下摆
        oval.set(cx - bodyW / 2f, hipY - bodyH * 0.16f + slump, cx + bodyW / 2f, hipY + h * 0.010f + slump);
        fill.setColor(C_SHIRT_DARK);
        canvas.drawRoundRect(oval, bodyW * 0.30f, bodyW * 0.30f, fill);

        // ---- 手臂（两段：肩→肘→手）
        final float shoulderL = cx - bodyW * 0.45f;
        final float shoulderR = cx + bodyW * 0.45f;
        final float topY = shoulderY + h * 0.018f + slump;

        if (state == CLING || state == DRAG) {
            // 双手举过头顶，像被拎着
            armTwo(canvas, shoulderL, topY, shoulderL - w * 0.06f, headCy - headR * 0.35f,
                    shoulderL - w * 0.02f, headCy - headR * 1.15f, w * 0.088f);
            armTwo(canvas, shoulderR, topY, shoulderR + w * 0.06f, headCy - headR * 0.35f,
                    shoulderR + w * 0.02f, headCy - headR * 1.15f, w * 0.088f);
        } else if (state == YAWN) {
            // 伸懒腰：双手向上摊开
            final float k = (float) Math.sin(Math.min(1f, activityT * 3f) * Math.PI * 0.5f);
            armTwo(canvas, shoulderL, topY, shoulderL - w * 0.10f * k, topY - bodyH * 0.30f * k,
                    shoulderL - w * 0.16f * k, topY - bodyH * 0.62f * k, w * 0.088f);
            armTwo(canvas, shoulderR, topY, shoulderR + w * 0.10f * k, topY - bodyH * 0.30f * k,
                    shoulderR + w * 0.16f * k, topY - bodyH * 0.62f * k, w * 0.088f);
        } else if (state == PHONE) {
            // 两手捧手机在胸前
            final float py = shoulderY + bodyH * 0.34f;
            armTwo(canvas, shoulderL, topY, shoulderL + bodyW * 0.16f, py - bodyH * 0.10f,
                    cx - w * 0.055f, py, w * 0.088f);
            armTwo(canvas, shoulderR, topY, shoulderR - bodyW * 0.16f, py - bodyH * 0.10f,
                    cx + w * 0.055f, py, w * 0.088f);
            drawPhone(canvas, cx, py, w);
        } else if (state == SMOKE) {
            // 一只手举到嘴边叼烟
            final float my = headCy + headR * 0.42f;
            armTwo(canvas, shoulderL, topY, shoulderL - w * 0.02f, shoulderY + bodyH * 0.30f,
                    cx - headR * 0.55f, my, w * 0.088f);
            drawCigarette(canvas, cx - headR * 0.50f, my, headR);
            armTwo(canvas, shoulderR, topY, shoulderR + w * 0.07f, shoulderY + bodyH * 0.40f,
                    shoulderR + w * 0.10f, shoulderY + bodyH * 0.72f, w * 0.088f);
        } else if (state == SLEEP) {
            // 睡觉：双手垂在身侧
            armTwo(canvas, shoulderL, topY, shoulderL - w * 0.01f, shoulderY + bodyH * 0.35f,
                    shoulderL - w * 0.02f, shoulderY + bodyH * 0.72f, w * 0.088f);
            armTwo(canvas, shoulderR, topY, shoulderR + w * 0.01f, shoulderY + bodyH * 0.35f,
                    shoulderR + w * 0.02f, shoulderY + bodyH * 0.72f, w * 0.088f);
        } else {
            final float armSwing = -swing * 0.9f;
            armTwo(canvas, shoulderL, topY, shoulderL - w * 0.03f + armSwing * 0.45f,
                    shoulderY + bodyH * 0.38f,
                    shoulderL - w * 0.05f + armSwing, shoulderY + bodyH * 0.70f, w * 0.088f);
            armTwo(canvas, shoulderR, topY, shoulderR + w * 0.03f - armSwing * 0.45f,
                    shoulderY + bodyH * 0.38f,
                    shoulderR + w * 0.05f - armSwing, shoulderY + bodyH * 0.70f, w * 0.088f);
        }

        // ---- 脖子
        oval.set(cx - w * 0.05f, neckY - h * 0.028f + slump,
                cx + w * 0.05f, neckY + h * 0.018f + slump);
        fill.setColor(C_SKIN_SHADE);
        canvas.drawRoundRect(oval, w * 0.045f, w * 0.045f, fill);

        // ---- 头（睡觉时低一点）
        final float headY = headCy + slump + (state == SLEEP ? headR * 0.10f : 0f);
        fill.setColor(C_SKIN);
        canvas.drawCircle(cx, headY, headR, fill);
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(dp(1.3f));
        canvas.drawCircle(cx, headY, headR, stroke);

        // 耳朵
        fill.setColor(C_SKIN_SHADE);
        canvas.drawCircle(cx - headR * 0.97f, headY + headR * 0.14f, headR * 0.19f, fill);
        canvas.drawCircle(cx + headR * 0.97f, headY + headR * 0.14f, headR * 0.19f, fill);

        drawHair(canvas, cx, headY, headR);
        drawAhoge(canvas, cx, headY, headR);
        drawFace(canvas, cx, headY, headR);
    }

    // ---------------------------------------------------------------- 头发与脸

    private void drawHair(Canvas canvas, float cx, float headCy, float headR) {
        path.reset();
        path.moveTo(cx - headR * 1.05f, headCy + headR * 0.05f);
        path.quadTo(cx - headR * 1.22f, headCy - headR * 1.22f, cx - headR * 0.08f, headCy - headR * 1.08f);
        path.quadTo(cx + headR * 1.14f, headCy - headR * 1.24f, cx + headR * 1.05f, headCy + headR * 0.05f);
        path.quadTo(cx + headR * 0.78f, headCy - headR * 0.58f, cx + headR * 0.30f, headCy - headR * 0.50f);
        path.quadTo(cx + headR * 0.06f, headCy - headR * 0.88f, cx - headR * 0.26f, headCy - headR * 0.46f);
        path.quadTo(cx - headR * 0.64f, headCy - headR * 0.56f, cx - headR * 1.05f, headCy + headR * 0.05f);
        path.close();
        fill.setColor(C_HAIR);
        canvas.drawPath(path, fill);

        // 发丝高光
        stroke.setColor(C_HAIR_HI);
        stroke.setStrokeWidth(dp(1.6f));
        path.reset();
        path.moveTo(cx - headR * 0.62f, headCy - headR * 0.95f);
        path.quadTo(cx - headR * 0.30f, headCy - headR * 1.16f, cx + headR * 0.10f, headCy - headR * 1.10f);
        canvas.drawPath(path, stroke);
    }

    private void drawAhoge(Canvas canvas, float cx, float headCy, float headR) {
        final float sway = (float) Math.sin(breathe * 1.7f) * headR * 0.18f;
        path.reset();
        path.moveTo(cx + headR * 0.04f, headCy - headR * 0.98f);
        path.quadTo(cx + headR * 0.10f + sway, headCy - headR * 1.55f,
                cx + headR * 0.50f + sway, headCy - headR * 1.32f);
        stroke.setColor(C_HAIR);
        stroke.setStrokeWidth(dp(1.9f));
        canvas.drawPath(path, stroke);
    }

    private void drawFace(Canvas canvas, float cx, float headCy, float headR) {
        final float fx = cx + facing * headR * 0.05f;
        final float eyeY = headCy + headR * 0.14f;
        final float gap = headR * 0.40f;
        final float eyeW = headR * 0.185f;
        final float eyeH = headR * 0.235f;

        if (state == HIT && hit > 0.35f) {
            // 被砸：X 眼
            drawXEye(canvas, fx - gap, eyeY, eyeH);
            drawXEye(canvas, fx + gap, eyeY, eyeH);
        } else if (state == SLEEP) {
            // 睡觉：闭眼弧线
            stroke.setColor(C_INK);
            stroke.setStrokeWidth(headR * 0.085f);
            oval.set(fx - gap - eyeW, eyeY - eyeH * 0.6f, fx - gap + eyeW, eyeY + eyeH * 0.6f);
            canvas.drawArc(oval, 20f, 140f, false, stroke);
            oval.set(fx + gap - eyeW, eyeY - eyeH * 0.6f, fx + gap + eyeW, eyeY + eyeH * 0.6f);
            canvas.drawArc(oval, 20f, 140f, false, stroke);
        } else if (state == JUMP || state == YAWN) {
            // 开心：^ ^
            stroke.setColor(C_INK);
            stroke.setStrokeWidth(headR * 0.095f);
            oval.set(fx - gap - eyeW, eyeY - eyeH * 0.35f, fx - gap + eyeW, eyeY + eyeH * 0.85f);
            canvas.drawArc(oval, 200f, 140f, false, stroke);
            oval.set(fx + gap - eyeW, eyeY - eyeH * 0.35f, fx + gap + eyeW, eyeY + eyeH * 0.85f);
            canvas.drawArc(oval, 200f, 140f, false, stroke);
        } else if (state == PHONE) {
            // 看手机：眼珠朝下
            drawEye(canvas, fx - gap, eyeY + eyeH * 0.35f, eyeW, eyeH, headR, 0.85f);
            drawEye(canvas, fx + gap, eyeY + eyeH * 0.35f, eyeW, eyeH, headR, 0.85f);
        } else {
            final float open = Math.max(0.10f, blink);
            drawEye(canvas, fx - gap, eyeY, eyeW, eyeH, headR, open);
            drawEye(canvas, fx + gap, eyeY, eyeW, eyeH, headR, open);
        }

        // 腮红
        soft.setColor(C_BLUSH);
        oval.set(fx - gap - eyeW * 1.85f, eyeY + headR * 0.20f,
                fx - gap - eyeW * 0.35f, eyeY + headR * 0.44f);
        canvas.drawOval(oval, soft);
        oval.set(fx + gap + eyeW * 0.35f, eyeY + headR * 0.20f,
                fx + gap + eyeW * 1.85f, eyeY + headR * 0.44f);
        canvas.drawOval(oval, soft);

        // 嘴
        drawMouth(canvas, fx, eyeY, headR);
    }

    private void drawEye(Canvas canvas, float x, float y, float eyeW, float eyeH,
                         float headR, float open) {
        final float hh = eyeH * open;
        fill.setColor(C_WHITE);
        oval.set(x - eyeW, y - hh, x + eyeW, y + hh);
        canvas.drawOval(oval, fill);

        fill.setColor(C_INK);
        canvas.drawCircle(x, y + hh * 0.12f, hh * 0.74f, fill);

        fill.setColor(C_WHITE);
        canvas.drawCircle(x - hh * 0.28f, y - hh * 0.30f, hh * 0.24f, fill);
    }

    private void drawXEye(Canvas canvas, float x, float y, float r) {
        stroke.setColor(C_INK);
        stroke.setStrokeWidth(r * 0.42f);
        canvas.drawLine(x - r, y - r, x + r, y + r, stroke);
        canvas.drawLine(x - r, y + r, x + r, y - r, stroke);
    }

    private void drawMouth(Canvas canvas, float fx, float eyeY, float headR) {
        final float my = eyeY + headR * 0.36f;
        stroke.setColor(C_INK);

        if (state == YAWN) {
            // 打哈欠：大张
            fill.setColor(0xFF7A3B3B);
            oval.set(fx - headR * 0.17f, my - headR * 0.16f, fx + headR * 0.17f, my + headR * 0.22f);
            canvas.drawOval(oval, fill);
            stroke.setStrokeWidth(headR * 0.05f);
            canvas.drawOval(oval, stroke);
        } else if (state == SLEEP) {
            stroke.setStrokeWidth(headR * 0.07f);
            canvas.drawLine(fx - headR * 0.10f, my, fx + headR * 0.10f, my, stroke);
        } else if (jaw > 0.25f || state == JUMP || state == HIT) {
            // 张嘴（说话 / 惊讶）
            final float o = Math.max(0.4f, jaw);
            fill.setColor(0xFF8A4A4A);
            oval.set(fx - headR * 0.13f * o, my - headR * 0.05f,
                    fx + headR * 0.13f * o, my + headR * 0.20f * o);
            canvas.drawOval(oval, fill);
            stroke.setStrokeWidth(headR * 0.045f);
            canvas.drawOval(oval, stroke);
        } else {
            // 微笑
            stroke.setStrokeWidth(headR * 0.075f);
            oval.set(fx - headR * 0.16f, my - headR * 0.16f, fx + headR * 0.16f, my + headR * 0.10f);
            canvas.drawArc(oval, 25f, 130f, false, stroke);
        }
    }

    // ---------------------------------------------------------------- 特效

    private void drawZzz(Canvas canvas, float w, float h) {
        final float base = (breathe * 0.6f) % 1f;
        for (int i = 0; i < 3; i++) {
            final float t = (base + i * 0.33f) % 1f;
            final int alpha = (int) ((1f - t) * 190);
            fill.setColor(0xFFFFFF | (alpha << 24));
            final float size = dp(7f) + t * dp(6f);
            fill.setTextSize(size);
            canvas.drawText("z", w * 0.60f + t * w * 0.10f, h * 0.28f - t * h * 0.20f, fill);
        }
    }

    private void drawDizzy(Canvas canvas, float cx, float h) {
        final float cy = h * 0.16f;
        final float t = (1f - hit) * 8f;
        for (int i = 0; i < 3; i++) {
            final float a = t + i * 2.1f;
            final float x = cx + (float) Math.cos(a) * dp(16f);
            final float y = cy + (float) Math.sin(a) * dp(6f);
            fill.setColor(0xFFFFD54F);
            star(canvas, x, y, dp(4f));
        }
    }

    private void star(Canvas canvas, float x, float y, float r) {
        path.reset();
        for (int i = 0; i < 10; i++) {
            final double ang = Math.PI / 5 * i - Math.PI / 2;
            final float rr = (i % 2 == 0) ? r : r * 0.45f;
            final float px = x + (float) Math.cos(ang) * rr;
            final float py = y + (float) Math.sin(ang) * rr;
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
        canvas.drawPath(path, fill);
    }

    private void drawHearts(Canvas canvas, float cx, float h) {
        final float t = 1f - jump;
        final int alpha = (int) (Math.min(1f, jump * 1.6f) * 220);
        soft.setColor((alpha << 24) | 0xFF5C7A);
        heart(canvas, cx - dp(22f) - t * dp(10f), h * 0.22f - t * h * 0.12f, dp(5f));
        heart(canvas, cx + dp(26f) + t * dp(10f), h * 0.18f - t * h * 0.10f, dp(4f));
    }

    private void heart(Canvas canvas, float x, float y, float r) {
        path.reset();
        path.moveTo(x, y + r * 0.9f);
        path.cubicTo(x - r * 1.5f, y - r * 0.4f, x - r * 0.6f, y - r * 1.5f, x, y - r * 0.45f);
        path.cubicTo(x + r * 0.6f, y - r * 1.5f, x + r * 1.5f, y - r * 0.4f, x, y + r * 0.9f);
        path.close();
        canvas.drawPath(path, soft);
    }

    private void drawSmoke(Canvas canvas, float w, float h) {
        final float t = breathe * 0.55f;
        final float ox = w * 0.40f;
        final float oy = h * 0.34f;
        for (int i = 0; i < 3; i++) {
            final float k = ((t + i * 0.33f) % 1f);
            final int alpha = (int) ((1f - k) * 150);
            soft.setColor((alpha << 24) | 0xD9D9D9);
            canvas.drawCircle(ox - k * w * 0.06f, oy - k * h * 0.16f, dp(2.5f) + k * dp(4f), soft);
        }
    }

    private void drawPhone(Canvas canvas, float cx, float y, float w) {
        final float pw = w * 0.16f;
        final float ph = w * 0.26f;
        oval.set(cx - pw / 2f, y - ph / 2f, cx + pw / 2f, y + ph / 2f);
        fill.setColor(C_PHONE);
        canvas.drawRoundRect(oval, dp(2f), dp(2f), fill);
        oval.set(cx - pw * 0.38f, y - ph * 0.40f, cx + pw * 0.38f, y + ph * 0.40f);
        fill.setColor(C_PHONE_LIGHT);
        canvas.drawRoundRect(oval, dp(1f), dp(1f), fill);
    }

    private void drawCigarette(Canvas canvas, float x, float y, float headR) {
        oval.set(x, y - headR * 0.05f, x + headR * 0.62f, y + headR * 0.05f);
        fill.setColor(C_PAPER);
        canvas.drawRoundRect(oval, dp(1f), dp(1f), fill);
        fill.setColor(C_EMBER);
        canvas.drawCircle(x + headR * 0.62f, y, headR * 0.075f, fill);
    }

    // ---------------------------------------------------------------- 部件

    private void legTwo(Canvas canvas, float x1, float y1, float kx, float ky, float x2, float y2, float cw) {
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(cw + dp(2.4f));
        canvas.drawLine(x1, y1, kx, ky, stroke);
        canvas.drawLine(kx, ky, x2, y2, stroke);
        stroke.setColor(C_PANTS);
        stroke.setStrokeWidth(cw);
        canvas.drawLine(x1, y1, kx, ky, stroke);
        canvas.drawLine(kx, ky, x2, y2, stroke);
    }

    private void armTwo(Canvas canvas, float x1, float y1, float ex, float ey, float x2, float y2, float cw) {
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(cw + dp(2.2f));
        canvas.drawLine(x1, y1, ex, ey, stroke);
        canvas.drawLine(ex, ey, x2, y2, stroke);
        stroke.setColor(C_SKIN);
        stroke.setStrokeWidth(cw);
        canvas.drawLine(x1, y1, ex, ey, stroke);
        canvas.drawLine(ex, ey, x2, y2, stroke);
        // 手
        fill.setColor(C_SKIN);
        canvas.drawCircle(x2, y2, cw * 0.62f, fill);
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(dp(1.0f));
        canvas.drawCircle(x2, y2, cw * 0.62f, stroke);
    }

    private void shoe(Canvas canvas, float x, float y, float r) {
        oval.set(x - r * 0.9f, y - r * 0.26f, x + r * 0.9f, y + r * 0.52f);
        fill.setColor(C_SHOE);
        canvas.drawOval(oval, fill);
        stroke.setColor(C_OUTLINE);
        stroke.setStrokeWidth(dp(1.0f));
        canvas.drawOval(oval, stroke);
    }

    // ---------------------------------------------------------------- 手势

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                dragging = false;
                return true;

            case MotionEvent.ACTION_MOVE: {
                final float dx = event.getX() - lastX;
                final float dy = event.getY() - lastY;
                if (!dragging
                        && Math.hypot(event.getX() - downX, event.getY() - downY) > slop) {
                    dragging = true;
                    if (host != null) host.onDragStart();
                    setState(DRAG);
                }
                if (dragging && host != null) host.onDragBy(dx, dy);
                lastX = event.getX();
                lastY = event.getY();
                return true;
            }

            case MotionEvent.ACTION_UP:
                if (dragging) {
                    if (host != null) host.onDragEnd();
                } else if (host != null) {
                    host.onPetTap();
                }
                dragging = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                if (dragging && host != null) host.onDragEnd();
                dragging = false;
                return true;

            default:
                return super.onTouchEvent(event);
        }
    }
}
