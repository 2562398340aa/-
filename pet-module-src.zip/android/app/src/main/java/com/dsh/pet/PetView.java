package com.dsh.pet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * 小人的画与手势都在这里。位置移动由 PetService 通过更新窗口坐标完成，
 * 这个 View 只负责「当前这一帧长什么样」。
 */
public class PetView extends View {

    public static final int STATE_IDLE = 0;   // 站着
    public static final int STATE_WALK = 1;   // 走路
    public static final int STATE_CLING = 2;  // 贴在边框上
    public static final int STATE_DRAG = 3;   // 被手指拖着

    public interface Host {
        void onDragStart();

        void onDragBy(float dx, float dy);

        void onDragEnd();

        void onPetTap();
    }

    private final Paint skinP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shirtP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hairP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint limbP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inkP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private Host host;
    private int state = STATE_IDLE;
    private int facing = 1;
    private float phase;
    private float breathe;
    private float react;
    private final int slop;

    private float downX, downY, lastX, lastY;
    private boolean dragging;

    public PetView(Context context) {
        super(context);
        skinP.setColor(0xFFFFDDB3);
        shirtP.setColor(0xFF4FC3F7);
        hairP.setColor(0xFF2E2A28);
        inkP.setColor(0xFF2B2B2B);
        shadowP.setColor(0x33000000);
        limbP.setStyle(Paint.Style.STROKE);
        limbP.setStrokeCap(Paint.Cap.ROUND);
        limbP.setStrokeJoin(Paint.Join.ROUND);
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public void setState(int newState) {
        if (state != newState) {
            state = newState;
            if (newState != STATE_WALK) phase = 0f;
            invalidate();
        }
    }

    public void setFacing(int direction) {
        facing = direction >= 0 ? 1 : -1;
    }

    public void react() {
        react = 1f;
        invalidate();
    }

    /** 由服务每帧调用，推进动画相位。 */
    public void tick(float dt) {
        breathe += dt * 2.2f;
        if (state == STATE_WALK) phase += dt * 7.5f;
        if (react > 0f) react = Math.max(0f, react - dt * 1.6f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        final float pad = h * 0.05f;
        final float ground = h - pad;
        final float bodyH = h * 0.80f;
        final float headR = w * 0.19f;
        final float headCy = ground - bodyH + headR;
        final float shoulderY = ground - bodyH * 0.70f;
        final float hipY = ground - bodyH * 0.40f;
        final float cx = w / 2f;

        float swing = 0f;
        if (state == STATE_WALK) swing = (float) Math.sin(phase) * w * 0.20f;

        float lift = 0f;
        if (state == STATE_IDLE) lift = (float) Math.sin(breathe) * h * 0.008f;
        if (react > 0f) lift -= (float) Math.sin(react * Math.PI) * h * 0.10f;

        canvas.save();
        canvas.translate(0f, lift);

        // 影子
        oval.set(cx - w * 0.22f, ground - h * 0.015f, cx + w * 0.22f, ground + h * 0.025f);
        canvas.drawOval(oval, shadowP);

        // 腿
        limbP.setColor(0xFF4E5A6A);
        limbP.setStrokeWidth(w * 0.075f);
        canvas.drawLine(cx - w * 0.01f, hipY, cx - w * 0.03f + swing, ground, limbP);
        canvas.drawLine(cx + w * 0.01f, hipY, cx + w * 0.03f - swing, ground, limbP);

        // 身体
        oval.set(cx - w * 0.17f, shoulderY, cx + w * 0.17f, hipY + h * 0.02f);
        canvas.drawRoundRect(oval, w * 0.10f, w * 0.10f, shirtP);

        // 手臂
        limbP.setColor(0xFFFFDDB3);
        limbP.setStrokeWidth(w * 0.062f);
        final float armLen = bodyH * 0.20f;
        if (state == STATE_CLING) {
            // 贴边：两只手往上抓
            canvas.drawLine(cx - w * 0.14f, shoulderY + h * 0.02f,
                    cx - w * 0.26f, shoulderY - armLen, limbP);
            canvas.drawLine(cx + w * 0.14f, shoulderY + h * 0.02f,
                    cx + w * 0.26f, shoulderY - armLen, limbP);
        } else if (state == STATE_DRAG) {
            canvas.drawLine(cx - w * 0.14f, shoulderY + h * 0.02f,
                    cx - w * 0.28f, shoulderY + armLen * 0.6f, limbP);
            canvas.drawLine(cx + w * 0.14f, shoulderY + h * 0.02f,
                    cx + w * 0.28f, shoulderY + armLen * 0.6f, limbP);
        } else {
            canvas.drawLine(cx - w * 0.14f, shoulderY + h * 0.02f,
                    cx - w * 0.20f - swing * 0.30f, shoulderY + armLen, limbP);
            canvas.drawLine(cx + w * 0.14f, shoulderY + h * 0.02f,
                    cx + w * 0.20f - swing * 0.30f, shoulderY + armLen, limbP);
        }

        // 头
        canvas.drawCircle(cx, headCy, headR, skinP);
        oval.set(cx - headR, headCy - headR, cx + headR, headCy + headR * 0.20f);
        canvas.drawArc(oval, 180f, 180f, true, hairP);

        // 脸
        final float fx = cx + facing * headR * 0.08f;
        final float eyeY = headCy - headR * 0.02f;
        final float eyeGap = headR * 0.38f;

        if (react > 0.35f) {
            // 被点时的开心眼：> <
            limbP.setColor(0xFF2B2B2B);
            limbP.setStrokeWidth(headR * 0.11f);
            canvas.drawLine(fx - eyeGap - headR * 0.10f, eyeY - headR * 0.07f,
                    fx - eyeGap + headR * 0.07f, eyeY, limbP);
            canvas.drawLine(fx - eyeGap - headR * 0.10f, eyeY + headR * 0.07f,
                    fx - eyeGap + headR * 0.07f, eyeY, limbP);
            canvas.drawLine(fx + eyeGap + headR * 0.10f, eyeY - headR * 0.07f,
                    fx + eyeGap - headR * 0.07f, eyeY, limbP);
            canvas.drawLine(fx + eyeGap + headR * 0.10f, eyeY + headR * 0.07f,
                    fx + eyeGap - headR * 0.07f, eyeY, limbP);
        } else {
            canvas.drawCircle(fx - eyeGap, eyeY, headR * 0.11f, inkP);
            canvas.drawCircle(fx + eyeGap, eyeY, headR * 0.11f, inkP);
        }

        // 嘴：平时微笑，被点时张大
        limbP.setColor(0xFF2B2B2B);
        if (react > 0.35f) {
            canvas.drawCircle(fx, eyeY + headR * 0.38f, headR * 0.14f, inkP);
        } else {
            limbP.setStrokeWidth(headR * 0.10f);
            oval.set(fx - headR * 0.22f, eyeY + headR * 0.10f,
                    fx + headR * 0.22f, eyeY + headR * 0.42f);
            canvas.drawArc(oval, 20f, 140f, false, limbP);
        }

        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                dragging = false;
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getX() - lastX;
                float dy = event.getY() - lastY;
                if (!dragging
                        && Math.hypot(event.getX() - downX, event.getY() - downY) > slop) {
                    dragging = true;
                    if (host != null) host.onDragStart();
                    setState(STATE_DRAG);
                }
                if (dragging && host != null) host.onDragBy(dx, dy);
                lastX = event.getX();
                lastY = event.getY();
                return true;
            }

            case MotionEvent.ACTION_UP:
                if (dragging) {
                    if (host != null) host.onDragEnd();
                } else if (host != null) {
                    host.onPetTap();
                }
                dragging = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                if (dragging && host != null) host.onDragEnd();
                dragging = false;
                return true;

            default:
                return super.onTouchEvent(event);
        }
    }
}
